# CHANGELOG.md

## 0.3.37 (06-07-2020)

Features:

  - Expose opening Result in ILockDiscoveryCallback
